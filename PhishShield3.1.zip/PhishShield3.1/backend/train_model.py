# backend/train_model.py
import argparse, os, pandas as pd, numpy as np, joblib
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, accuracy_score
from sklearn.ensemble import GradientBoostingClassifier
import features

def normalize_label(v):
    s = str(v).strip().lower()
    if s in {"1","true","yes","y","phish","phishing","bad","malicious"}:
        return 1
    if s in {"0","false","no","n","legit","benign","good","safe"}:
        return 0
    try:
        return int(float(s))
    except:
        return 0

def build_X(df):
    feat_rows = []
    for url in df["url"].astype(str).values:
        f = features.extract_url_features(url)
        feat_rows.append([f.get(k, 0) for k in features.FEATURE_ORDER])
    X = np.array(feat_rows, dtype=float)
    return X

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", required=True, help="Path to dataset CSV with columns: url,label")
    args = ap.parse_args()

    if not os.path.exists(args.data):
        print("[!] Dataset not found:", args.data)
        return

    df = pd.read_csv(args.data)
    if "url" not in df.columns or "label" not in df.columns:
        print("[!] CSV must contain 'url' and 'label' columns.")
        return
    df = df.dropna(subset=["url","label"]).copy()
    df["label"] = df["label"].map(normalize_label)

    X = build_X(df)
    y = df["label"].values.astype(int)

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)
    clf = GradientBoostingClassifier(random_state=42)
    clf.fit(X_train, y_train)

    y_pred = clf.predict(X_test)
    y_proba = clf.predict_proba(X_test)[:,1]

    acc = accuracy_score(y_test, y_pred)
    print(f"[+] Accuracy: {acc:.4f}")
    print(classification_report(y_test, y_pred, digits=4))

    out_path = os.path.join(os.path.dirname(__file__), "model.pkl")
    joblib.dump(clf, out_path)
    print("[+] Saved model to:", out_path)

if __name__ == "__main__":
    main()
