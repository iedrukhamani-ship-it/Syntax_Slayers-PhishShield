# PhishShield (Backend - Local Server)

Hello! This is the "brain" of PhishShield. It:
- Learns from examples (your dataset) what phishing URLs look like.
- Checks links and pages for danger signs.
- Talks to the Chrome extension and gives it a score.

You will:
- Put your dataset file here.
- Train the ML model (one command).
- Start the server (one command).

Step 0: Install Python
- Make sure Python 3.10 or newer is installed.
- On Windows, you can check by opening "CMD" and typing: python --version

Step 1: Install things the server needs
- Open CMD in this folder (phishshield/backend)
- Type this and press Enter:
  pip install -r requirements.txt

Step 2: Put your dataset file
- Put your dataset CSV file here: phishshield/backend/data/dataset.csv
- The file must have columns: url,label
- The label can be 1/0 or phishing/legit (we handle both)

Example of 3 lines:
url,label
http://paypal.com,0
http://pa-ypal.com.verify-user-login.co,1
http://google.com,0

Step 3: Train the model
- In CMD (in phishshield/backend), run:
  python train_model.py --data data/dataset.csv

What happens:
- The script reads your CSV, learns URL patterns, and saves a model file: model.pkl
- It also prints accuracy so you see how good it is.

Step 4: Set VirusTotal (optional, but nice)
- Get a free API key from virustotal.com (create a free account).
- Create a file named .env in this folder (phishshield/backend) and put:
  VT_API_KEY=your_virustotal_key_here
- If you skip this, it still works, just without VirusTotal.

Step 5: Start the server
- In CMD (phishshield/backend), run:
  python app.py
- You should see: "PhishShield backend running at http://127.0.0.1:5000"

Step 6: Use the extension
- Make sure Chrome extension is loaded (see frontend/README.md).
- Visit websites and see PhishShield in action!

How it works inside (simple words):
- Fast checks (URL level): We look for weird symbols, too many dots, IP addresses, strange words like "verify" in the URL. Fast and instant.
- Domain checks (WHOIS): We check how old the domain is. Very new domains are often bad.
- Content checks: We look for "login/password" forms where they shouldn't be, scary words like "urgent", and sneaky scripts.
- VirusTotal check: If you gave an API key, we ask VirusTotal if the domain/URL is known to be bad.
- Blacklist: We download OpenPhish (public phishing feed) to block known bad sites.

Scoring rules:
- We mix ML prediction + rules + VirusTotal + blacklist = final score (0 to 100)
- 0-30: safe (green)
- 31-65: suspicious (yellow)
- 80-100: dangerous (red, usually blocked)

Need help?
- If something fails, read messages in CMD. Most errors will say exactly what is wrong.
