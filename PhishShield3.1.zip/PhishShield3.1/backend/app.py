# backend/app.py
import os, time, threading, socket, json
from datetime import datetime, timezone
from flask import Flask, request, jsonify
from flask_cors import CORS
import numpy as np
import joblib
import requests

import features
import feeds
import vt

MODEL = None
FEATURE_ORDER = features.FEATURE_ORDER

app = Flask(__name__)
CORS(app)

CACHE = {}  # url -> { ts, result }
CACHE_TTL = 300  # seconds

def load_model():
    global MODEL
    model_path = os.path.join(os.path.dirname(__file__), "model.pkl")
    if os.path.exists(model_path):
        try:
            MODEL = joblib.load(model_path)
            print("[+] Model loaded:", model_path)
        except Exception as e:
            print("[!] Failed to load model:", e)
            MODEL = None
    else:
        print("[!] No model.pkl found yet. Run train_model.py first.")
load_model()

def score_from_model(url_features):
    global MODEL
    if MODEL is None:
        return 0.0
    x = np.array([[url_features.get(k, 0) for k in FEATURE_ORDER]])
    try:
        proba = MODEL.predict_proba(x)[0, 1]
        return float(proba)
    except Exception as e:
        print("[!] Model inference error:", e)
        return 0.0

def aggregate_score(proba_ml, heur_score, domain_score, content_score, vt_score, listed_bad):
    # Base from ML
    score = proba_ml * 70.0
    score += min(heur_score, 20)
    score += min(domain_score, 20)
    score += min(content_score, 25)
    score += min(vt_score, 30)
    if listed_bad:
        score = max(score, 95)  # near block
    return max(0.0, min(100.0, score))

def label_from_score(score):
    if score <= 30: return "safe"
    if score >= 80: return "dangerous"
    return "suspicious"

@app.route("/health")
def health():
    return jsonify({"ok": True})

@app.route("/score", methods=["POST"])
def score():
    data = request.get_json(force=True, silent=True) or {}
    url = (data.get("url") or "").strip()
    mode = (data.get("mode") or "fast").strip().lower()
    content = data.get("content") or {}

    if not url:
        return jsonify({"error": "Missing URL"}), 400

    # normalize
    if not url.lower().startswith(("http://","https://")):
        url = "http://" + url

    # caching
    now = time.time()
    cache_key = f"{mode}:{url}"
    item = CACHE.get(cache_key)
    if item and (now - item["ts"] < CACHE_TTL) and mode != "full":
        return jsonify(item["result"])

    reasons = []
    # FAST URL-LEVEL FEATURES
    url_feats = features.extract_url_features(url)
    heur_score, heur_reasons = features.quick_heuristics(url, url_feats)
    reasons.extend(heur_reasons)

    # Blacklist check (OpenPhish)
    listed_bad = feeds.is_blacklisted(url)
    if listed_bad:
        reasons.append("URL found in OpenPhish blacklist")

    # ML probability
    proba_ml = score_from_model(url_feats)
    if proba_ml >= 0.8: reasons.append("ML model: very high phishing probability")
    elif proba_ml >= 0.6: reasons.append("ML model: high phishing probability")
    elif proba_ml >= 0.4: reasons.append("ML model: moderate phishing probability")
    else: reasons.append("ML model: low phishing probability")

    # DOMAIN-LEVEL (WHOIS / Domain age / DNS)
    domain_score = 0.0
    if mode != "hover":
        dctx = features.domain_context(url)
        domain_score += dctx.get("suspicion", 0.0)
        reasons.extend(dctx.get("reasons", []))

    # CONTENT-LEVEL (provided by extension)
    content_score, content_reasons = features.content_suspicion(content)
    reasons.extend(content_reasons)

    # VIRUSTOTAL (optional)
    vt_score = 0.0
    vt_reason = None
    if mode != "hover":
        try:
            vt_data = vt.check_domain_or_url(url)
            vt_score = vt_data.get("score", 0.0)
            if vt_data.get("desc"):
                vt_reason = vt_data["desc"]
                reasons.append(vt_reason)
        except Exception as e:
            reasons.append("VirusTotal check failed or not configured")

    final_score = aggregate_score(proba_ml, heur_score, domain_score, content_score, vt_score, listed_bad)
    label = label_from_score(final_score)
    action = "allow"
    if final_score >= 80 or listed_bad:
        action = "block"
    elif final_score > 30:
        action = "warn"

    result = {
        "score": final_score,
        "label": label,
        "action": action,
        "reasons": reasons[:20]
    }
    CACHE[cache_key] = {"ts": time.time(), "result": result}
    return jsonify(result)

def start_feeds():
    try:
        feeds.init_feeds_async()
        print("[+] OpenPhish feed updater started.")
    except Exception as e:
        print("[!] Feed updater failed:", e)

if __name__ == "__main__":
    start_feeds()
    host = "127.0.0.1"
    port = 5000
    print(f"[+] PhishShield backend running at http://{host}:{port}")
    app.run(host=host, port=port, debug=False)
