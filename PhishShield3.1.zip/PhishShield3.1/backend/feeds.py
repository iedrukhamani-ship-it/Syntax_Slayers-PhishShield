# backend/feeds.py
import threading, time, requests
from urllib.parse import urlparse

BLACKLIST_URLS = set()
BLACKLIST_DOMAINS = set()
LAST_UPDATE = 0

def fetch_openphish():
    url = "https://openphish.com/feed.txt"
    try:
        r = requests.get(url, timeout=10)
        if r.ok:
            lines = [x.strip() for x in r.text.splitlines() if x.strip()]
            return lines
    except Exception:
        pass
    return []

def update_feeds():
    global BLACKLIST_URLS, BLACKLIST_DOMAINS, LAST_UPDATE
    urls = fetch_openphish()
    domains = set()
    for u in urls:
        try:
            d = urlparse(u).hostname or ""
            if d:
                domains.add(d.lower())
        except Exception:
            pass
    BLACKLIST_URLS = set(urls)
    BLACKLIST_DOMAINS = domains
    LAST_UPDATE = time.time()
    print(f"[+] OpenPhish feed: {len(BLACKLIST_URLS)} URLs, {len(BLACKLIST_DOMAINS)} domains")

def refresher():
    while True:
        try:
            update_feeds()
        except Exception as e:
            print("[!] OpenPhish update failed:", e)
        time.sleep(6*60*60)  # every 6 hours

def init_feeds_async():
    t = threading.Thread(target=refresher, daemon=True)
    t.start()

def is_blacklisted(url: str):
    try:
        from urllib.parse import urlparse
        p = urlparse(url)
        d = (p.hostname or "").lower()
        if url in BLACKLIST_URLS: return True
        if d in BLACKLIST_DOMAINS: return True
    except Exception:
        pass
    return False
