# backend/features.py
import re, math, socket, time
from urllib.parse import urlparse
import ipaddress
import tldextract
import whois
from datetime import datetime, timezone

SUSPICIOUS_KEYWORDS_URL = [
    "login", "verify", "update", "secure", "account", "bank", "confirm", "unlock",
    "reset", "password", "signin", "wp-admin", "payment", "invoice"
]

BRANDS = ["paypal","apple","google","microsoft","amazon","facebook","instagram",
          "twitter","bankofamerica","chase","wellsfargo","netflix","adobe",
          "yahoo","linkedin","coinbase","icloud","onedrive","dropbox","outlook"]

FEATURE_ORDER = [
    "url_length",
    "hostname_length",
    "path_length",
    "query_length",
    "num_dots",
    "num_hyphens",
    "num_special",
    "num_digits",
    "num_subdirs",
    "num_params",
    "tld_length",
    "has_https",
    "is_ip",
    "has_port",
    "has_at",
    "has_punycode",
    "sus_kw_count",
    "entropy",
]

def shannon_entropy(s: str) -> float:
    if not s: return 0.0
    prob = [float(s.count(c)) / len(s) for c in set(s)]
    return -sum([p * math.log(p, 2) for p in prob])

def is_ip(host: str) -> bool:
    try:
        ipaddress.ip_address(host)
        return True
    except Exception:
        return False

def extract_url_features(url: str) -> dict:
    try:
        p = urlparse(url)
    except Exception:
        p = urlparse("http://" + url)

    host = p.hostname or ""
    path = p.path or ""
    query = p.query or ""

    has_https = int(p.scheme.lower() == "https")
    has_port = int(p.port is not None)
    has_at = int("@" in url)
    has_punycode = int("xn--" in host.lower())

    num_dots = host.count(".")
    num_hyphens = host.count("-")
    num_digits = sum(c.isdigit() for c in url)
    num_subdirs = path.count("/")
    num_params = query.count("&") + (1 if "=" in query else 0)
    num_special = sum(url.count(c) for c in ["@", "%", "=", "&"])

    ext = tldextract.extract(host)
    tld = ext.suffix or ""
    tld_length = len(tld)
    hostname_length = len(host)

    sus_kw_count = sum(1 for k in SUSPICIOUS_KEYWORDS_URL if k in url.lower())
    entropy = shannon_entropy(url)

    feats = {
        "url_length": len(url),
        "hostname_length": hostname_length,
        "path_length": len(path),
        "query_length": len(query),
        "num_dots": num_dots,
        "num_hyphens": num_hyphens,
        "num_special": num_special,
        "num_digits": num_digits,
        "num_subdirs": num_subdirs,
        "num_params": num_params,
        "tld_length": tld_length,
        "has_https": has_https,
        "is_ip": int(is_ip(host)),
        "has_port": has_port,
        "has_at": has_at,
        "has_punycode": has_punycode,
        "sus_kw_count": sus_kw_count,
        "entropy": float(entropy),
    }
    return feats

def quick_heuristics(url: str, feats: dict):
    score = 0.0
    reasons = []

    if feats.get("has_at"): score += 5; reasons.append("URL contains '@' (phishing trick)")
    if feats.get("is_ip"): score += 10; reasons.append("URL uses raw IP instead of domain")
    if feats.get("num_dots", 0) >= 4: score += 5; reasons.append("URL has many dots/subdomains")
    if feats.get("num_hyphens", 0) >= 3: score += 5; reasons.append("URL has many hyphens")
    if feats.get("sus_kw_count", 0) >= 2: score += 8; reasons.append("Suspicious keywords in URL")
    if feats.get("entropy", 0) > 4.0: score += 4; reasons.append("High URL entropy (random-looking)")
    if feats.get("has_punycode"): score += 4; reasons.append("Punycode domain (possible homograph)")
    if feats.get("has_https") == 0: score += 3; reasons.append("No HTTPS")

    return score, reasons

def _listify_date(d):
    # whois may return list or single date
    if isinstance(d, list):
        d = d[0]
    return d

def domain_context(url: str):
    out = {"suspicion": 0.0, "reasons": []}
    try:
        host = urlparse(url).hostname or ""
    except Exception:
        return out
    if not host:
        return out

    # domain age via WHOIS
    try:
        w = whois.whois(host)
        cdate = _listify_date(w.creation_date)
        if isinstance(cdate, str):
            try:
                cdate = datetime.fromisoformat(cdate)
            except Exception:
                cdate = None
        if cdate:
            if not cdate.tzinfo:
                cdate = cdate.replace(tzinfo=timezone.utc)
            age_days = (datetime.now(timezone.utc) - cdate).days
            if age_days < 30:
                out["suspicion"] += 8
                out["reasons"].append(f"Very new domain ({age_days} days old)")
            elif age_days < 180:
                out["suspicion"] += 3
                out["reasons"].append(f"Newish domain ({age_days} days old)")
        else:
            out["suspicion"] += 2
            out["reasons"].append("WHOIS creation date missing")
    except Exception:
        out["suspicion"] += 2
        out["reasons"].append("WHOIS lookup failed")

    # DNS resolve check
    try:
        socket.gethostbyname(host)
    except Exception:
        out["suspicion"] += 4
        out["reasons"].append("DNS resolution failed")

    # brand mismatch hint
    lowhost = host.lower()
    for b in BRANDS:
        if b in lowhost:
            out["reasons"].append(f"Brand mention in domain: {b}")
    return out

def content_suspicion(content: dict):
    if not content:
        return 0.0, []
    score = 0.0
    reasons = []
    kw = int(content.get("keywordHits") or 0)
    pwd = int(content.get("pwdInputs") or 0)
    email = int(content.get("emailInputs") or 0)
    forms = int(content.get("formsCount") or 0)
    obf = int(content.get("obfuscationHits") or 0)
    pop = int(content.get("popupHits") or 0)
    brands = int(content.get("brandMentions") or 0)
    ext_hosts = content.get("externalHosts") or []

    if kw >= 5:
        score += 6; reasons.append("Many suspicious words on page")
    elif kw >= 2:
        score += 3; reasons.append("Some suspicious words on page")

    if pwd >= 1 and forms >= 1:
        score += 6; reasons.append("Asking for password on this page")

    if (pwd >= 1 or email >= 1) and kw >= 1:
        score += 3; reasons.append("Credentials requested with suspicious wording")

    if obf >= 2:
        score += 6; reasons.append("Obfuscated/inline JavaScript detected")
    elif obf >= 1:
        score += 3; reasons.append("Inline JavaScript usage")

    if pop >= 1:
        score += 2; reasons.append("Popup/forced prompt patterns")

    if brands >= 2:
        score += 3; reasons.append("Multiple brand mentions in content")

    shady_exts = sum(1 for h in ext_hosts if h and any(b in h.lower() for b in ["cdn.", "track", "ad", "click", "stat", "metrics"]))
    if shady_exts >= 3:
        score += 3; reasons.append("Many external resources from tracking-like hosts")

    return score, reasons
