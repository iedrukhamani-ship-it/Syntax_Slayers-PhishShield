# backend/vt.py
import os, requests
from urllib.parse import urlparse

VT_API_KEY = None

def _get_key():
    global VT_API_KEY
    if VT_API_KEY: return VT_API_KEY
    # Try .env file
    env_path = os.path.join(os.path.dirname(__file__), ".env")
    if os.path.exists(env_path):
        for line in open(env_path, "r", encoding="utf-8"):
            if line.strip().startswith("VT_API_KEY="):
                VT_API_KEY = line.strip().split("=",1)[1].strip()
                break
    # Try environment
    if not VT_API_KEY:
        VT_API_KEY = os.environ.get("VT_API_KEY", "").strip()
    return VT_API_KEY

def vt_headers():
    key = _get_key()
    if not key:
        return None
    return {"x-apikey": key}

def vt_domain_reputation(domain: str):
    h = vt_headers()
    if not h: return None
    try:
        url = f"https://www.virustotal.com/api/v3/domains/{domain}"
        r = requests.get(url, headers=h, timeout=8)
        if not r.ok:
            return None
        data = r.json()
        stats = data.get("data", {}).get("attributes", {}).get("last_analysis_stats", {})
        malicious = int(stats.get("malicious", 0))
        suspicious = int(stats.get("suspicious", 0))
        harmless = int(stats.get("harmless", 0))
        undetected = int(stats.get("undetected", 0))
        total = malicious + suspicious + harmless + undetected
        return {"malicious": malicious, "suspicious": suspicious, "total": total}
    except Exception:
        return None

def check_domain_or_url(url: str):
    # Use domain endpoint for speed and limits
    try:
        domain = urlparse(url).hostname or ""
    except Exception:
        domain = ""
    rep = vt_domain_reputation(domain) if domain else None
    if not rep:
        return {"score": 0.0, "desc": None}
    mal = rep.get("malicious", 0)
    susp = rep.get("suspicious", 0)
    score = min(30.0, mal*10 + susp*5)  # cap at 30
    desc = None
    if mal > 0 or susp > 0:
        desc = f"VirusTotal: malicious={mal}, suspicious={susp}"
    return {"score": score, "desc": desc}
