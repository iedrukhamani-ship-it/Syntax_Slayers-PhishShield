// frontend/content.js
const backendBase = "http://127.0.0.1:5000"; // Not used from content directly; background does requests.
const HOVER_DELAY_MS = 250;

let hoverTimer = null;
let tooltipEl = null;
let lastHoverUrl = null;
let hoverCache = new Map(); // url -> {ts, res}

function createTooltip() {
  if (tooltipEl) return tooltipEl;
  tooltipEl = document.createElement("div");
  tooltipEl.id = "phishshield-tooltip";
  tooltipEl.className = "phishshield-tooltip";
  tooltipEl.style.display = "none";
  document.documentElement.appendChild(tooltipEl);
  return tooltipEl;
}

function showTooltip(x, y, content, color) {
  const el = createTooltip();
  el.innerHTML = content;
  el.style.borderColor = color;
  el.style.boxShadow = `0 8px 24px ${color}55`;
  el.style.left = (x + 12) + "px";
  el.style.top = (y + 12) + "px";
  el.style.display = "block";
}

function hideTooltip() {
  if (tooltipEl) tooltipEl.style.display = "none";
}

function colorForScore(score) {
  if (score <= 30) return "#2ecc71";
  if (score >= 80) return "#e74c3c";
  return "#f1c40f";
}

function onLinkHover(e) {
  const a = e.target.closest("a[href]");
  if (!a) return;
  const url = a.href;
  lastHoverUrl = url;

  const cached = hoverCache.get(url);
  if (cached && (Date.now() - cached.ts < 30000)) {
    const c = colorForScore(cached.res.score);
    showTooltip(e.pageX, e.pageY, `Risk: ${Math.round(cached.res.score)}<br>${cached.res.label}`, c);
    return;
  }

  showTooltip(e.pageX, e.pageY, "Checking link…", "#3498db");
  clearTimeout(hoverTimer);
  hoverTimer = setTimeout(() => {
    chrome.runtime.sendMessage({ type: "SCORE_URL_HOVER", url }, (res) => {
      if (!res) return;
      hoverCache.set(url, { ts: Date.now(), res });
      if (lastHoverUrl === url) {
        const c = colorForScore(res.score);
        showTooltip(e.pageX, e.pageY, `Risk: ${Math.round(res.score)}<br>${res.label}`, c);
      }
    });
  }, HOVER_DELAY_MS);
}

function onMouseOut(e) {
  if (!e.relatedTarget || !e.relatedTarget.closest || !e.relatedTarget.closest("#phishshield-tooltip")) {
    hideTooltip();
  }
}

// Page banner UI
let bannerEl = null;
function ensureBanner() {
  if (bannerEl) return bannerEl;
  bannerEl = document.createElement("div");
  bannerEl.className = "phishshield-banner";
  bannerEl.innerHTML = `
    <div class="ps-left">
      <span class="ps-title">PhishShield</span>
      <span class="ps-status">Checking…</span>
    </div>
    <div class="ps-actions">
      <button class="ps-btn ps-back" style="display:none;">Go back</button>
      <button class="ps-btn ps-proceed" style="display:none;">Proceed anyway</button>
      <button class="ps-close" title="Hide alert">×</button>
    </div>
  `;
  document.documentElement.appendChild(bannerEl);

  bannerEl.querySelector(".ps-close").addEventListener("click", () => bannerEl.remove());
  bannerEl.querySelector(".ps-back").addEventListener("click", () => {
    chrome.runtime.sendMessage({ type: "GO_BACK" });
  });
  bannerEl.querySelector(".ps-proceed").addEventListener("click", () => {
    chrome.runtime.sendMessage({ type: "PROCEED_ANYWAY", url: location.href });
  });
  return bannerEl;
}

function setBanner(score, reasons) {
  const el = ensureBanner();
  const statusEl = el.querySelector(".ps-status");
  const backBtn = el.querySelector(".ps-back");
  const proceedBtn = el.querySelector(".ps-proceed");

  let color = "#2ecc71", label = "Safe";
  if (score >= 80) { color = "#e74c3c"; label = "Dangerous"; }
  else if (score > 30) { color = "#f1c40f"; label = "Suspicious"; }

  el.style.borderColor = color;
  el.style.boxShadow = `0 6px 20px ${color}55`;
  statusEl.textContent = `${label} (Score: ${Math.round(score)})`;

  if (score >= 80) {
    backBtn.style.display = "inline-block";
    proceedBtn.style.display = "inline-block";
  } else if (score > 30) {
    backBtn.style.display = "inline-block";
    proceedBtn.style.display = "inline-block";
  } else {
    backBtn.style.display = "none";
    proceedBtn.style.display = "none";
  }

  if (reasons && reasons.length) {
    statusEl.title = reasons.join(" | ");
  }
}

function collectContentFeatures() {
  const text = document.body ? document.body.innerText || "" : "";
  const lowered = text.toLowerCase();

  const keywords = [
    "verify", "account", "reset", "password", "urgent", "login", "sign in",
    "update", "bank", "invoice", "payment", "limited", "suspend", "unlock",
    "confirm", "security", "paypal", "apple", "google", "microsoft"
  ];
  let keywordHits = 0;
  for (const k of keywords) if (lowered.includes(k)) keywordHits++;

  const forms = Array.from(document.querySelectorAll("form"));
  const inputs = Array.from(document.querySelectorAll("input"));
  const pwdInputs = inputs.filter(i => (i.type || "").toLowerCase() === "password").length;
  const emailInputs = inputs.filter(i => (i.type || "").toLowerCase() === "email").length;

  const scripts = Array.from(document.scripts || []);
  const inlineScripts = scripts.filter(s => !s.src).map(s => s.textContent || "").join("\n").toLowerCase();
  const externalScripts = scripts.filter(s => !!s.src).map(s => s.src);
  const externalHosts = externalScripts.map(u => {
    try { return (new URL(u)).hostname; } catch(e){ return null; }
  }).filter(Boolean);

  const obfuscationPatterns = ["eval(", "unescape(", "fromcharcode", "atob(", "document.write("];
  let obfuscationHits = 0;
  for (const p of obfuscationPatterns) if (inlineScripts.includes(p)) obfuscationHits++;

  const popupPatterns = ["alert(", "confirm(", "prompt(", "onbeforeunload", "setinterval(", "settimeout("];
  let popupHits = 0;
  for (const p of popupPatterns) if (inlineScripts.includes(p)) popupHits++;

  const brandList = ["paypal","apple","google","microsoft","amazon","facebook","instagram","twitter","bank","dropbox","netflix","adobe","yahoo","linkedin","coinbase"];
  let brandMentions = 0;
  for (const b of brandList) if (lowered.includes(b)) brandMentions++;

  return {
    keywordHits,
    formsCount: forms.length,
    pwdInputs,
    emailInputs,
    externalHosts,
    obfuscationHits,
    popupHits,
    brandMentions,
  };
}

function sendPageFeatures() {
  const features = collectContentFeatures();
  chrome.runtime.sendMessage({ type: "PAGE_FEATURES", url: location.href, features }, (res) => {
    if (!res) return;
    setBanner(res.score, res.reasons || []);
  });
}

// Listeners
document.addEventListener("mouseover", onLinkHover, { passive: true });
document.addEventListener("mouseout", onMouseOut, { passive: true });

// Run banner + content analysis
ensureBanner();
setBanner(0, ["Checking..."]);
if (document.readyState === "complete" || document.readyState === "interactive") {
  setTimeout(sendPageFeatures, 500);
} else {
  window.addEventListener("DOMContentLoaded", () => setTimeout(sendPageFeatures, 500));
}
