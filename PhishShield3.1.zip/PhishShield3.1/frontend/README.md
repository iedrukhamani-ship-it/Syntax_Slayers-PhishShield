# PhishShield (Frontend - Chrome Extension)

Hello! This is the "face" of our project — the part you see in Chrome.

What it does:
- Shows a colored banner on websites (Green = Safe, Yellow = Suspicious, Red = Dangerous).
- Blocks very dangerous sites with a big warning page.
- Shows a small score bubble when you hover links, so you know if a link is safe.
- Shows a popup when you click the extension icon with more details and buttons.

How to install it (like teaching a kid):
1) Open Google Chrome.
2) In the top bar, type: chrome://extensions and press Enter.
3) Turn ON "Developer mode" (top right).
4) Click the button "Load unpacked".
5) Find and select the folder: phishshield/frontend
6) You will now see PhishShield appear in your extensions list (with a shield icon).

How to use:
- Start the backend server first (see backend/README.md).
- Visit any website. A tiny banner at the top will say "Safe", "Suspicious", or "Dangerous".
- Hover over any link to see a small safety score tooltip.
- If a site is dangerous, PhishShield will block it. You can choose to "Proceed anyway" (not recommended) or "Go back".
- Click the extension icon to open the popup showing the score and reasons.

Notes:
- The extension connects to a local server at http://127.0.0.1:5000
- If the server is off, you'll see "Backend unavailable" in reasons.
- You can whitelist a site by clicking "Proceed anyway" so PhishShield will stop warning you for that domain.
