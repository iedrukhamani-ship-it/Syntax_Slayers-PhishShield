// frontend/block.js
function getQueryParam(key) {
  const url = new URL(location.href);
  return url.searchParams.get(key) || "";
}
const orig = getQueryParam("orig");
const reason = decodeURIComponent(getQueryParam("reason") || "");
document.getElementById("origUrl").textContent = orig;
document.getElementById("reason").textContent = reason || "High risk phishing indicators";

document.getElementById("back").addEventListener("click", () => history.back());
document.getElementById("proceed").addEventListener("click", () => {
  chrome.runtime.sendMessage({ type: "PROCEED_ANYWAY", url: orig }, () => {
    // background will whitelist and navigate
  });
});
