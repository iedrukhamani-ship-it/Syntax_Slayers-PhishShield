// frontend/popup.js
function ringColor(score) {
  if (score <= 30) return "#2ecc71";
  if (score >= 80) return "#e74c3c";
  return "#f1c40f";
}

function updateUI(data) {
  const ring = document.getElementById("scoreRing");
  const num = document.getElementById("scoreNumber");
  const label = document.getElementById("scoreLabel");
  const reasonsEl = document.getElementById("reasons");
  const backBtn = document.getElementById("goBack");
  const proceedBtn = document.getElementById("proceed");

  if (!data) {
    num.textContent = "--";
    label.textContent = "No data yet";
    ring.style.borderColor = "#95a5a6";
    reasonsEl.textContent = "Navigate to a page or wait a bit.";
    backBtn.style.display = "none";
    proceedBtn.style.display = "none";
    return;
  }

  const score = Math.round(data.score || 0);
  num.textContent = score;
  ring.style.borderColor = ringColor(score);
  label.textContent = data.label || (score <= 30 ? "Safe" : (score >= 80 ? "Dangerous" : "Suspicious"));

  reasonsEl.innerHTML = (data.reasons || []).slice(0, 6).map(r => `<div>• ${r}</div>`).join("") || "";

  if (score > 30) {
    backBtn.style.display = "inline-block";
    proceedBtn.style.display = "inline-block";
  } else {
    backBtn.style.display = "none";
    proceedBtn.style.display = "none";
  }
}

async function getActiveTab() {
  const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  return tabs[0];
}

(async () => {
  const tab = await getActiveTab();
  chrome.runtime.sendMessage({ type: "GET_LAST_SCORE", tabId: tab.id }, (res) => updateUI(res));

  document.getElementById("goBack").addEventListener("click", () => {
    chrome.runtime.sendMessage({ type: "GO_BACK" });
    window.close();
  });
  document.getElementById("proceed").addEventListener("click", async () => {
    chrome.runtime.sendMessage({ type: "PROCEED_ANYWAY", url: tab.url });
    window.close();
  });
})();
