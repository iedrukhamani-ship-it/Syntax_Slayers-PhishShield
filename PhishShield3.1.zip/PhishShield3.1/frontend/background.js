// frontend/background.js
const backendBase = "http://127.0.0.1:5000";
const SCORE_SAFE_THRESHOLD = 30;      // <= 30 => green
const SCORE_WARN_THRESHOLD = 65;      // 31..65 => yellow
const SCORE_BLOCK_THRESHOLD = 80;     // >= 80 => red block
const REQUEST_TIMEOUT_MS = 4000;

let lastTabScores = {}; // tabId -> result object
let whitelist = new Set(); // domains user allowed
let blacklist = new Set(); // optionally user blacklist
let cache = new Map();     // url -> {ts, result}

function extractDomain(u) {
  try { return new URL(u).hostname.toLowerCase(); } catch (e) { return ""; }
}
function normalizeUrl(u) {
  try {
    if (!/^https?:\/\//i.test(u)) u = "http://" + u;
    return new URL(u).toString();
  } catch(e) { return u; }
}

async function loadUserLists() {
  const data = await chrome.storage.local.get(["userWhitelist", "userBlacklist"]);
  (data.userWhitelist || []).forEach(d => whitelist.add(d));
  (data.userBlacklist || []).forEach(d => blacklist.add(d));
}
loadUserLists();

function saveWhitelist() {
  chrome.storage.local.set({ userWhitelist: Array.from(whitelist) });
}
function saveBlacklist() {
  chrome.storage.local.set({ userBlacklist: Array.from(blacklist) });
}

function setBadge(tabId, score) {
  let text = "";
  let color = "#999999";
  if (score === null || score === undefined) {
    text = "…";
    color = "#95a5a6";
  } else if (score <= SCORE_SAFE_THRESHOLD) {
    text = "SAFE";
    color = "#2ecc71";
  } else if (score >= SCORE_BLOCK_THRESHOLD) {
    text = "DANG";
    color = "#e74c3c";
  } else {
    text = "WARN";
    color = "#f1c40f";
  }
  chrome.action.setBadgeText({ tabId, text });
  chrome.action.setBadgeBackgroundColor({ tabId, color });
}

function withTimeout(promise, ms) {
  const timeout = new Promise((_res, reject) => setTimeout(() => reject(new Error("timeout")), ms));
  return Promise.race([promise, timeout]).catch(e => { throw e; });
}

async function fetchScore(body) {
  const url = `${backendBase}/score`;
  const res = await withTimeout(fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body)
  }), REQUEST_TIMEOUT_MS);
  if (!res.ok) throw new Error("Backend returned " + res.status);
  return res.json();
}

async function scoreUrl(url, mode="fast", contentFeatures=null) {
  url = normalizeUrl(url);
  const domain = extractDomain(url);
  if (whitelist.has(domain)) {
    return { score: 0, label: "safe", reasons: ["User whitelisted"], action: "allow" };
  }
  if (blacklist.has(domain)) {
    return { score: 95, label: "dangerous", reasons: ["User blacklisted"], action: "block" };
  }
  const cacheKey = `${mode}:${url}`;
  const now = Date.now();
  const cached = cache.get(cacheKey);
  if (cached && (now - cached.ts < 60_000)) {
    return cached.result;
  }
  const body = { url, mode };
  if (contentFeatures) body.content = contentFeatures;
  try {
    const result = await fetchScore(body);
    cache.set(cacheKey, { ts: Date.now(), result });
    return result;
  } catch (e) {
    return { score: 0, label: "safe", reasons: ["Backend unavailable"], action: "allow", error: String(e) };
  }
}

async function maybeBlock(tabId, url, result) {
  if (!result) return;
  if (result.action === "block" || result.score >= SCORE_BLOCK_THRESHOLD) {
    const blockUrl = chrome.runtime.getURL("block.html") + 
      `?orig=${encodeURIComponent(url)}&reason=${encodeURIComponent((result.reasons||[]).join("; "))}`;
    try {
      await chrome.tabs.update(tabId, { url: blockUrl });
    } catch (e) {
      // ignore
    }
  }
}

chrome.webNavigation.onCommitted.addListener(async (details) => {
  if (details.frameId !== 0) return; // only top-level
  const tabId = details.tabId;
  const url = details.url;

  // Quick check first (fast)
  setBadge(tabId, null);
  const quick = await scoreUrl(url, "fast");
  lastTabScores[tabId] = quick;
  setBadge(tabId, quick.score);
  await maybeBlock(tabId, url, quick);
}, { url: [{ urlMatches: ".*" }] });

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  (async () => {
    if (msg.type === "SCORE_URL_HOVER") {
      const res = await scoreUrl(msg.url, "hover");
      sendResponse(res);
    } else if (msg.type === "PAGE_FEATURES") {
      // full score with content
      const tabId = sender.tab ? sender.tab.id : null;
      const url = msg.url;
      const res = await scoreUrl(url, "full", msg.features || {});
      if (tabId != null) {
        lastTabScores[tabId] = res;
        setBadge(tabId, res.score);
        await maybeBlock(tabId, url, res);
      }
      sendResponse(res);
    } else if (msg.type === "GET_LAST_SCORE") {
      const tabId = msg.tabId || (sender.tab ? sender.tab.id : null);
      const res = (tabId != null) ? lastTabScores[tabId] : null;
      sendResponse(res || null);
    } else if (msg.type === "WHITELIST_ADD") {
      const domain = extractDomain(msg.url || msg.domain || "");
      if (domain) { whitelist.add(domain); saveWhitelist(); }
      sendResponse({ ok: true, domain });
    } else if (msg.type === "BLACKLIST_ADD") {
      const domain = extractDomain(msg.url || msg.domain || "");
      if (domain) { blacklist.add(domain); saveBlacklist(); }
      sendResponse({ ok: true, domain });
    } else if (msg.type === "GO_BACK") {
      if (sender.tab && sender.tab.id) {
        chrome.tabs.goBack(sender.tab.id).catch(()=>{});
      }
      sendResponse({ ok: true });
    } else if (msg.type === "PROCEED_ANYWAY") {
      const domain = extractDomain(msg.url || "");
      if (domain) { whitelist.add(domain); saveWhitelist(); }
      if (sender.tab && sender.tab.id && msg.url) {
        try { await chrome.tabs.update(sender.tab.id, { url: msg.url }); } catch (e) {}
      }
      sendResponse({ ok: true });
    }
  })();
  return true; // keep the channel open for async
});
