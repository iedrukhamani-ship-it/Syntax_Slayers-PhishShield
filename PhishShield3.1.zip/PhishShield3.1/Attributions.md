# Attributions

This document lists the technologies, libraries, and tools used in the development of the PhishShield program.

---

## Frontend (Chrome Extension)
The frontend is a Chrome extension that interacts with the backend to provide real-time phishing detection.

### Technologies Used:
- **HTML5**: For structuring the extension's user interface (e.g., `popup.html`, `block.html`).
- **CSS3**: For styling the extension's UI (e.g., `banner.css`, `block.css`, `hover.css`, `popup.css`).
- **JavaScript (ES6)**: For implementing the extension's logic and interactivity (e.g., `background.js`, `content.js`, `popup.js`, `block.js`).
- **Chrome Extensions API**: For interacting with the browser (e.g., `chrome.runtime`, `chrome.storage`, `chrome.webNavigation`).
- **Manifest v3**: For defining the extension's metadata and permissions (`manifest.json`).

### Assets:
- **Icons**: PNG images for the extension's icons (`assets/icon-16.png`, `assets/icon-48.png`, `assets/icon-128.png`).

---

## Backend (Python Server)
The backend is a Python server that performs phishing detection using machine learning, heuristics, and external APIs.

### Technologies Used:
- **Python 3.10+**: The primary programming language for the backend.
- **Flask**: A lightweight web framework for building the backend API (`app.py`).
- **Flask-CORS**: For enabling Cross-Origin Resource Sharing (CORS) in the backend.
- **scikit-learn**: For training and using machine learning models (`train_model.py`).
- **NumPy**: For numerical computations (`features.py`, `train_model.py`).
- **Pandas**: For data manipulation and analysis (`train_model.py`).
- **Joblib**: For saving and loading machine learning models (`train_model.py`).
- **Requests**: For making HTTP requests to external services (`vt.py`, `feeds.py`).
- **dotenv**: For managing environment variables (`config.example.env`).


---

## Data and Machine Learning
- **Dataset**: A CSV file containing labeled URLs for training the machine learning model (`data/dataset.csv`). Dataset downloaded from Kaggle(phishing_site_urls.csv)
- **Gradient Boosting Classifier**: A machine learning algorithm used for phishing detection (`train_model.py`).
- **Feature Engineering**: Custom features extracted from URLs, domains, and page content (`features.py`).

---

## General Tools and Libraries
- **Requirements File**: Dependencies are listed in `requirements.txt` for easy installation.
---

## Development and Deployment
- **Google Chrome**: The target browser for the extension.
- **Command Line Interface (CLI)**: For running scripts like `train_model.py` and `app.py`.

---

## Folder Structure
- **Frontend**: Contains the Chrome extension files.
- **Backend**: Contains the Python server files, dataset, and machine learning model.

---

This program combines modern web technologies, machine learning, and external APIs to provide a robust phishing detection system.